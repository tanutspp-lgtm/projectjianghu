# MAP11 V21 — ลบชานเกยกัน + เพิ่มทางเชือก (Frontend / Backend ต้องอัปคู่กัน)

แก้จริงใน Frontend index.html และ `assets/forest_fork_11/map11_geometry_v21.json`
ลบชาน: (1620,1880,-105), (1680,2010,-270)
เพิ่มเชือกขึ้นเขา: x1900 จาก y=-25 ไป -185, x2020 จาก y=-185 ไป -355
ขยับชานเชื่อมกลางจาก x1910..2140 ไป x1855..2085 เพื่อให้ปีนลงได้จริง (ระบบเกมลงเชือกแล้วเดินออกด้านขวา 45px)
ชานอื่นและรูปพื้นหลังเดิม, แพลตฟอร์มวาร์ปชั้นบน, เชือกสองจุดเดิมทั้งหมด คงเดิม

Backend: ไฟล์นี้เป็น PATCH เท่านั้น ไม่ใช่ live server ของ Hostatom
ใช้ `python3 merge_map11_v21.py /path/to/current/server.py /path/to/new-server.py`
ตัวช่วยจะสร้างไฟล์ใหม่และ diff เสมอ ไม่เขียนทับ server เดิม และตรวจ capability V20/V3 ก่อนแทนที่
ฝั่ง frontend ต้องรองรับ feature `forest-fork-map11-v21-clean-ropes` เพื่อป้องกัน collision ไม่ตรงกัน
ไม่มีการ deploy / git push / restart server

Portal ไป Map12 ยังเป็นภาพตกแต่ง (ทางเดินขึ้นไปถึงได้ แต่ยังวาร์ปไป Map12 ไม่ได้)
